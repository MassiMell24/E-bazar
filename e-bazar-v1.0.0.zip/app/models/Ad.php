<?php

class Ad {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function getAll() {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM ads WHERE sold = 0");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            // If schema is not migrated yet (missing column), avoid fatal crash and return empty list
            error_log('Ad::getAll error: ' . $e->getMessage());
            return [];
        }
    }

    public function create(array $data) {
        $stmt = $this->pdo->prepare("INSERT INTO ads (owner_id, category_id, title, description, price, delivery_modes) VALUES (:owner_id, :category_id, :title, :description, :price, :delivery_modes)");
        $stmt->execute([
            ':owner_id' => $data['owner_id'] ?? null,
            ':category_id' => $data['category_id'] ?? null,
            ':title' => $data['title'],
            ':description' => $data['description'] ?? '',
            ':price' => $data['price'] ?? 0,
            ':delivery_modes' => $data['delivery_modes'] ?? ''
        ]);
        return $this->pdo->lastInsertId();
    }

    public function find($id) {
        if (!is_numeric($id)) {
            return false;
        }
        $stmt = $this->pdo->prepare("SELECT * FROM ads WHERE id = :id LIMIT 1");
        $stmt->bindValue(':id', (int)$id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }
}
