<h2>Déposer une annonce</h2>

<?php if (!empty($error)): ?>
    <p style="color:red"><?php echo htmlspecialchars($error); ?></p>
<?php endif; ?>

<form method="post" action="/e-bazar/index.php?url=ad/store">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
    <div>
        <label>Titre</label>
        <input type="text" name="title" required minlength="5" maxlength="30">
    </div>
    <div>
        <label>Description</label>
        <textarea name="description" required minlength="5" maxlength="200"></textarea>
    </div>
    <div>
        <label>Prix (€)</label>
        <input type="number" step="0.01" name="price" value="0">
    </div>
    <div>
        <label>Modes de livraison</label>
        <div><label><input type="checkbox" name="delivery[]" value="postal"> Postal</label></div>
        <div><label><input type="checkbox" name="delivery[]" value="hand"> Remise en main propre</label></div>
    </div>
    <div>
        <button type="submit">Publier</button>
    </div>
</form>
