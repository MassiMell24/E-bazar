<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>e-bazar</title>
    <script type="module" src="/e-bazar/public/assets/js/controllers/adController.js"></script>
</head>
<body>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$userId = $_SESSION['user_id'] ?? null;
$isAdmin = $_SESSION['is_admin'] ?? false;
?>
<header>
    <h1>e-bazar</h1>
    <nav>
        <a href="/e-bazar/">Accueil</a>
        <?php if ($userId): ?>
            | <a href="/e-bazar/index.php?url=ad/create">Déposer une annonce</a>
            | <a href="/e-bazar/index.php?url=dashboard/myAds">Mon compte</a>
            | <a href="/e-bazar/index.php?url=auth/logout">Se déconnecter</a>
            <?php if ($isAdmin): ?> | <a href="/e-bazar/index.php?url=admin/dashboard">Admin</a><?php endif; ?>
        <?php else: ?>
            | <a href="/e-bazar/index.php?url=auth/register">S'inscrire</a>
            | <a href="/e-bazar/index.php?url=auth/login">Se connecter</a>
        <?php endif; ?>
    </nav>
</header>
