<h2>Administration</h2>

<p>Nombre d'utilisateurs : <?php echo htmlspecialchars($usersCount); ?></p>
<p>Nombre d'annonces : <?php echo htmlspecialchars($adsCount); ?></p>
