<h2>Inscription</h2>

<?php if (!empty($error)): ?>
    <p style="color:red"><?php echo htmlspecialchars($error); ?></p>
<?php endif; ?>

<form method="post" action="/e-bazar/index.php?url=auth/register">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>">
    <div>
        <label>Email</label>
        <input type="email" name="email" required>
    </div>
    <div>
        <label>Mot de passe (>=6)</label>
        <input type="password" name="password" required>
    </div>
    <div>
        <button type="submit">S'inscrire</button>
    </div>
</form>
