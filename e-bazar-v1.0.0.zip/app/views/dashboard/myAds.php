<h2>Mes annonces</h2>

<?php if (empty($ads)): ?>
    <p>Aucune annonce pour le moment.</p>
<?php else: ?>
    <ul>
    <?php foreach ($ads as $a): ?>
        <li><?php echo htmlspecialchars($a['title']); ?> - <?php echo htmlspecialchars($a['price']); ?>€ - <?php echo $a['sold'] ? 'Vendu' : 'En vente'; ?></li>
    <?php endforeach; ?>
    </ul>
<?php endif; ?>
