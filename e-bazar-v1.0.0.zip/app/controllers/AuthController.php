<?php
require_once 'app/models/User.php';

class AuthController {
    private $pdo;
    private $userModel;

    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
        $this->userModel = new User($pdo);
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $csrf = $_POST['csrf_token'] ?? '';

            if (!isset($_SESSION['csrf_token']) || !$csrf || !hash_equals($_SESSION['csrf_token'], $csrf)) {
                $error = 'Token CSRF invalide';
                require 'app/views/layout/header.php';
                require 'app/views/auth/register.php';
                require 'app/views/layout/footer.php';
                return;
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
                $error = 'Email invalide ou mot de passe trop court (>=6)';
                require 'app/views/layout/header.php';
                require 'app/views/auth/register.php';
                require 'app/views/layout/footer.php';
                return;
            }

            if ($this->userModel->findByEmail($email)) {
                $error = 'Email déjà utilisé';
                require 'app/views/layout/header.php';
                require 'app/views/auth/register.php';
                require 'app/views/layout/footer.php';
                return;
            }

            $this->userModel->create($email, $password);
            header('Location: /e-bazar/index.php?url=auth/login');
            exit;
        }

        // GET
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
        require 'app/views/layout/header.php';
        require 'app/views/auth/register.php';
        require 'app/views/layout/footer.php';
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $csrf = $_POST['csrf_token'] ?? '';

            if (!isset($_SESSION['csrf_token']) || !$csrf || !hash_equals($_SESSION['csrf_token'], $csrf)) {
                $error = 'Token CSRF invalide';
                require 'app/views/layout/header.php';
                require 'app/views/auth/login.php';
                require 'app/views/layout/footer.php';
                return;
            }

            $user = $this->userModel->findByEmail($email);
            if (!$user || !password_verify($password, $user['password_hash'])) {
                $error = 'Identifiants invalides';
                require 'app/views/layout/header.php';
                require 'app/views/auth/login.php';
                require 'app/views/layout/footer.php';
                return;
            }

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['is_admin'] = (bool)$user['is_admin'];
            header('Location: /e-bazar/');
            exit;
        }

        // GET
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
        require 'app/views/layout/header.php';
        require 'app/views/auth/login.php';
        require 'app/views/layout/footer.php';
    }

    public function logout() {
        session_unset();
        session_destroy();
        header('Location: /e-bazar/');
        exit;
    }
}
