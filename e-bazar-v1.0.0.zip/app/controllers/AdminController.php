<?php
class AdminController {
    private $pdo;

    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
    }

    public function dashboard() {
        if (empty($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
            http_response_code(403);
            echo "Accès réservé à l'administrateur";
            return;
        }

        // Very simple overview
        $stmt = $this->pdo->query('SELECT COUNT(*) as c FROM users');
        $usersCount = $stmt->fetch()['c'];
        $stmt = $this->pdo->query('SELECT COUNT(*) as c FROM ads');
        $adsCount = $stmt->fetch()['c'];

        require 'app/views/layout/header.php';
        require 'app/views/admin/dashboard.php';
        require 'app/views/layout/footer.php';
    }
}
