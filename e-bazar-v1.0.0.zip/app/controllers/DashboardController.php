<?php
class DashboardController {
    private $pdo;
    private $adModel;

    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
        require_once 'app/models/Ad.php';
        $this->adModel = new Ad($pdo);
    }

    public function myAds() {
        if (empty($_SESSION['user_id'])) {
            header('Location: /e-bazar/index.php?url=auth/login');
            exit;
        }

        $stmt = $this->pdo->prepare('SELECT * FROM ads WHERE owner_id = :uid');
        $stmt->execute([':uid' => $_SESSION['user_id']]);
        $ads = $stmt->fetchAll();

        require 'app/views/layout/header.php';
        require 'app/views/dashboard/myAds.php';
        require 'app/views/layout/footer.php';
    }
}
