<?php
// require_once 'app/core/Controller.php'; // Si vous créez Controller.php
require_once 'app/models/Ad.php';

class AdController {
    private $pdo;
    private $adModel;
    
    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
        $this->adModel = new Ad($pdo);
    }
    
    public function index() {
        $ads = $this->adModel->getAll();
        
        // Rendu avec header/footer
        require 'app/views/layout/header.php';
        require 'app/views/ads/list.php';
        require 'app/views/layout/footer.php';
    }
    
    public function show($id) {
        $ad = $this->adModel->find($id);
        if (!$ad) {
            http_response_code(404);
            echo "Annonce non trouvée";
            return;
        }
        
        require 'app/views/layout/header.php';
        echo "<h2>" . htmlspecialchars($ad['title']) . "</h2>";
        echo "<p>Prix: " . htmlspecialchars($ad['price']) . "€</p>";
        require 'app/views/layout/footer.php';
    }

    public function create() {
        // only for authenticated users
        if (empty($_SESSION['user_id'])) {
            header('Location: /e-bazar/index.php?url=auth/login');
            exit;
        }

        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
        require 'app/views/layout/header.php';
        require 'app/views/ads/create.php';
        require 'app/views/layout/footer.php';
    }

    public function store() {
        if (empty($_SESSION['user_id'])) {
            header('Location: /e-bazar/index.php?url=auth/login');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo "Method not allowed";
            return;
        }

        $csrf = $_POST['csrf_token'] ?? '';
        if (!isset($_SESSION['csrf_token']) || !$csrf || !hash_equals($_SESSION['csrf_token'], $csrf)) {
            echo "Invalid CSRF";
            return;
        }

        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $delivery = implode(',', $_POST['delivery'] ?? []);

        if (strlen($title) < 5 || strlen($title) > 30 || strlen($description) < 5 || strlen($description) > 200) {
            $error = 'Validation failed';
            require 'app/views/layout/header.php';
            require 'app/views/ads/create.php';
            require 'app/views/layout/footer.php';
            return;
        }

        $data = [
            'owner_id' => $_SESSION['user_id'],
            'title' => $title,
            'description' => $description,
            'price' => $price,
            'delivery_modes' => $delivery
        ];

        $id = $this->adModel->create($data);
        header('Location: /e-bazar/index.php?url=ad/show/' . $id);
        exit;
    }
}