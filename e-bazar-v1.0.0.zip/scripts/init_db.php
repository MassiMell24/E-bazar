<?php
// Simple DB init / seed script. Usage: php scripts/init_db.php
require_once __DIR__ . '/../config/database.php';

// Create users table if not exists (use schema.sql ideally)
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Ensure ads table has extended columns (owner_id, description, delivery_modes, created_at)
$pdo->exec("CREATE TABLE IF NOT EXISTS ads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_id INT DEFAULT NULL,
    category_id INT DEFAULT NULL,
    title VARCHAR(100) NOT NULL,
    description VARCHAR(1000) DEFAULT '',
    price DECIMAL(10,2) DEFAULT 0.00,
    delivery_modes VARCHAR(100) DEFAULT '',
    sold BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// If the table existed previously, ensure required columns are present (safe migration)
$cols = ['sold' => "ALTER TABLE ads ADD COLUMN sold BOOLEAN DEFAULT 0",
         'created_at' => "ALTER TABLE ads ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP",
         'owner_id' => "ALTER TABLE ads ADD COLUMN owner_id INT DEFAULT NULL",
         'description' => "ALTER TABLE ads ADD COLUMN description VARCHAR(1000) DEFAULT ''",
         'delivery_modes' => "ALTER TABLE ads ADD COLUMN delivery_modes VARCHAR(100) DEFAULT ''"];

foreach ($cols as $col => $sql) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM ads LIKE :col");
        $stmt->execute([':col' => $col]);
        $found = $stmt->fetch();
        if (!$found) {
            $pdo->exec($sql);
            echo "Added column $col to ads table.\n";
        }
    } catch (Exception $e) {
        // If table doesn't exist yet, ignore; it will be created by CREATE TABLE IF NOT EXISTS above
    }
}

// Create default admin if missing
$adminEmail = 'admin@ebazar.local';
$stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email');
$stmt->execute([':email' => $adminEmail]);
if (!$stmt->fetch()) {
    $hash = password_hash('admin', PASSWORD_DEFAULT);
    $ins = $pdo->prepare('INSERT INTO users (email, password_hash, is_admin) VALUES (:email, :hash, 1)');
    $ins->execute([':email' => $adminEmail, ':hash' => $hash]);
    echo "Created default admin (email: $adminEmail, password: admin)\n";
} else {
    echo "Admin already exists\n";
}

echo "DB init/seed done.\n";
