export function renderAds(ads) {
    const ul = document.getElementById('ads');
    ul.innerHTML = '';

    ads.forEach(ad => {
        const li = document.createElement('li');
        li.textContent = ad.title + ' - ' + ad.price + '€';
        ul.appendChild(li);
    });
}
