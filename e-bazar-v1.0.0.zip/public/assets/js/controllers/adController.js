import { fetchAds } from '../models/adModel.js';
import { renderAds } from '../views/adView.js';

fetchAds().then(renderAds);
